package com.mkce.springbootbasics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootbasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootbasicsApplication.class, args);
	}

}
