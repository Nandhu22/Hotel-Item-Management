package com.mkce.springbootbasics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootbasicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
